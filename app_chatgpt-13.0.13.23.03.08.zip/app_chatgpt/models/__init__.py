# -*- coding: utf-8 -*-
# Copyright (c) 2020-Present InTechual Solutions. (<https://intechualsolutions.com/>)

from . import mail_channel
from . import res_config_settings
from . import ai_robot
from . import res_users
from . import mail_message
